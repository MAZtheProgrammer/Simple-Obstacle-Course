using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovementUpdated : MonoBehaviour
{
    public KeyCode forward = KeyCode.W;
    public KeyCode back = KeyCode.S;
    public KeyCode left = KeyCode.A;
    public KeyCode right = KeyCode.D;
    public KeyCode jump = KeyCode.Space;

    bool canJump = true;
    Vector3 direction;   
    Rigidbody rb;

    public float moveSpeed = 0.2f;
    public float jumpForce = 600f;
    public Vector3 resetPosition = new Vector3(0,3,0);
        
    void OnCollisionStay(Collision collision)
    {
        // if colliding with something, let player jump
        canJump = true;
    }

    void Start()
    {
        // Get this object's RigidBody component
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        // If has fallen off, reset position
        if (transform.position.y < -10f)
        {
            transform.position = resetPosition;
            rb.velocity = new Vector3(0f, 0f, 0f);
            rb.angularVelocity = new Vector3(0f, 0f, 0f);

        }

        // Jump
        if (Input.GetKeyDown(jump) && canJump)
        {
            canJump = false;
            rb.AddForce(Vector3.up * jumpForce);
            
        }


        /* 
        *direction* is a variable that will control which direction we move and look.
        It starts as (0,0,0) and we will add to it using the if statements below
        */
        direction = Vector3.zero;

        if (Input.GetKey(forward))
        {
            // i.e. make direction (0,0,1)
            direction += Vector3.forward;
        }

        if (Input.GetKey(back))
        {
            direction += Vector3.back;
        }

        if (Input.GetKey(left))
        {
            direction += Vector3.left;
        }

        if (Input.GetKey(right))
        {
            direction += Vector3.right;
        }

        // move us [speed] units in [direction]
        rb.MovePosition(transform.position + direction * moveSpeed);
        //transform.position += direction * moveSpeed;

        // get the player to look in the direction they are moving,
        // unless they are standing still, when they should face the camera
        if (direction == Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(Vector3.back);
        }
        else
        {
            transform.rotation = Quaternion.LookRotation(direction);
        }
    }
}
