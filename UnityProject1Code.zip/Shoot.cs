using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shoot : MonoBehaviour
{
    public GameObject cannonballPrefab;
    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("SpawnOneBall", 0f, 3f);

    }

    // Update is called once per frame
    void Update()
    {

    }
    void SpawnOneBall()
    {
        GameObject newCannonball = Instantiate(cannonballPrefab, transform.position + Vector3.forward, transform.rotation);
        Rigidbody rb = newCannonball.GetComponent<Rigidbody>();
        rb.AddRelativeForce(Vector3.back * 100000f);
    }
}