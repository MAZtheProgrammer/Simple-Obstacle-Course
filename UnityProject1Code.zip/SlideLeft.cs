using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlideLeft : MonoBehaviour
{
    public float speed = 20f;
    public Vector3 resetPosition;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = transform.TransformPoint(Vector3.left * speed * Time.deltaTime);
        if(transform.position.x < -13f)
        {
            transform.position = resetPosition;
        }
    }
}
